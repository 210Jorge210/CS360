package com.example.jareventtrackapp;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class AddEventActivity extends AppCompatActivity {

    EditText eventName, eventDate, eventTime;
    Button saveEventBtn, enableSmsBtn;
    TextView smsStatusText;

    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);

        eventName = findViewById(R.id.eventName);
        eventDate = findViewById(R.id.eventDate);
        eventTime = findViewById(R.id.eventTime);
        saveEventBtn = findViewById(R.id.saveEventBtn);
        enableSmsBtn = findViewById(R.id.enableSmsBtn);
        smsStatusText = findViewById(R.id.smsStatusText);

        dbHelper = new DatabaseHelper(this);

        // SAVE EVENT
        saveEventBtn.setOnClickListener(v -> {

            String name = eventName.getText().toString();
            String date = eventDate.getText().toString();
            String time = eventTime.getText().toString();

            SQLiteDatabase db = dbHelper.getWritableDatabase();

            db.execSQL("INSERT INTO events (name, date, time) VALUES (?, ?, ?)",
                    new Object[]{name, date, time});

            Toast.makeText(this, "Event Saved", Toast.LENGTH_SHORT).show();
            finish();
        });

        // SMS PERMISSION
        enableSmsBtn.setOnClickListener(v -> {

            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS}, 1);

                smsStatusText.setText("Requesting permission...");

            } else {
                smsStatusText.setText("SMS Permission Already Granted");
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {

        if (requestCode == 1) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                smsStatusText.setText("SMS Permission Granted");

            } else {
                smsStatusText.setText("SMS Permission Denied");
            }
        }
    }
}