package com.example.jareventtrackapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class EventActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    GridLayout eventGrid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        Button addEventBtn = findViewById(R.id.addEventBtn);
        eventGrid = findViewById(R.id.eventGrid);

        dbHelper = new DatabaseHelper(this);

        loadEvents();

        addEventBtn.setOnClickListener(v -> {
            startActivity(new Intent(EventActivity.this, AddEventActivity.class));
        });
    }

    private void loadEvents() {

        eventGrid.removeAllViews();

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM events", null);

        while (cursor.moveToNext()) {

            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            String date = cursor.getString(2);
            String time = cursor.getString(3);

            TextView tv = new TextView(this);
            tv.setText(name + " - " + date + " " + time);
            tv.setPadding(10,10,10,10);

            Button deleteBtn = new Button(this);
            deleteBtn.setText("Delete");

            deleteBtn.setOnClickListener(v -> {
                SQLiteDatabase dbWrite = dbHelper.getWritableDatabase();
                dbWrite.execSQL("DELETE FROM events WHERE id=?", new Object[]{id});
                loadEvents(); // refresh
            });

            eventGrid.addView(tv);
            eventGrid.addView(deleteBtn);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadEvents(); // refresh when returning
    }
}