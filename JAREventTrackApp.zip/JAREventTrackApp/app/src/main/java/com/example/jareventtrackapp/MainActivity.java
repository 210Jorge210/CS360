package com.example.jareventtrackapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText usernameInput, passwordInput;
    Button loginBtn;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginBtn = findViewById(R.id.loginBtn);

        dbHelper = new DatabaseHelper(this);

        loginBtn.setOnClickListener(v -> {

            String username = usernameInput.getText().toString();
            String password = passwordInput.getText().toString();

            SQLiteDatabase db = dbHelper.getReadableDatabase();

            Cursor cursor = db.rawQuery(
                    "SELECT * FROM users WHERE username=? AND password=?",
                    new String[]{username, password}
            );

            if (cursor.moveToFirst()) {
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "New user created", Toast.LENGTH_SHORT).show();

                SQLiteDatabase dbWrite = dbHelper.getWritableDatabase();
                dbWrite.execSQL("INSERT INTO users (username, password) VALUES (?, ?)",
                        new Object[]{username, password});
            }

            startActivity(new Intent(MainActivity.this, EventActivity.class));
        });
    }
}